from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponse
from rest_framework import serializers
from rest_framework.parsers import JSONParser

from .models import Category,Post,Reviews

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username','email']
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class PostSerializer(serializers.ModelSerializer):
    #category = CategorySerializer(read_only=True) #--- this read only used to convert the json to object and keep it for listing(GET) it wont be updated...
    # post_author = UserSerializer(read_only=True)
    post_title = serializers.CharField(max_length=100, min_length=5, allow_blank=False, trim_whitespace=True)  #this is validation..can take from this site:https://www.django-rest-framework.org/api-guide/fields/#charfield

    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())  #this queryset will check the data on category table.. if not it will display an error
    category_details = CategorySerializer(source='category',read_only=True)
    post_author = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    post_author_details = UserSerializer(source='post_author',read_only=True)

    # post_author_username = serializers.SerializerMethodField()



    class Meta:
        model = Post
        fields = ['post_author', 'post_author_details', 'post_description', 'post_shortname','post_title','category','category_details', 'post_image']

    # def get_post_author_username(self, obj):
    #     return obj.post_author.username

    #override create method
    def create(self, validated_data):
        validated_data['post_title'] = validated_data['post_title'].upper() #here validated data means the data from the JSON object, so we are selecting the specific data post_title to change
        return super().create(validated_data)
        #with super keyword accessed the parent class() and passed the newly modified
        # validated_data to parent class' create method.'

class ReviewsSerializer(serializers.ModelSerializer):
    post_details = PostSerializer(source='post',read_only=True)
    post = serializers.PrimaryKeyRelatedField(queryset=Post.objects.all())

    class Meta:
        model = Reviews
        fields = ['post','post_details','rating', 'description','review_author']


class SignupSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

    def create(self, validated_data):
        validated_data['password'] = make_password(validated_data['password'])
        return super(SignupSerializer, self).create(validated_data)

#serializer for login:

class LoginSerializer(serializers.ModelSerializer):
    username = serializers.CharField()
    class Meta:
        model = User
        fields = ['username', 'password']
