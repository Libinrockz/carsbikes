from django.conf import settings
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token


# Create your models here.
class Category(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True)

    def __str__(self):
        return self.title


class Post(models.Model):
    post_title = models.CharField(max_length=50)
    post_description = models.CharField(max_length=200)
    post_shortname = models.SlugField(max_length=200, unique=True)
    post_published_datetime = models.DateTimeField(auto_now_add=True)
    post_author = models.ForeignKey(User, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, default=1, related_name='posts_category', on_delete=models.CASCADE)
    post_image = models.ImageField(upload_to="my_picture",blank=True, null=True)
    def __str__(self):
        return self.post_title

class Reviews(models.Model):
    STARS = (
        (1, 'One Star'),
        (2, 'Two Star'),
        (3, 'Three Star'),
        (4, 'Four Star'),
        (5, 'Five Star'),
    )
    post = (models.ForeignKey(Post, related_name='reviews_of_post', on_delete=models.CASCADE))
    rating = models.IntegerField(choices=STARS, default=1)
    description = models.CharField(max_length=200)
    review_author = models.ForeignKey(User, on_delete=models.CASCADE, default=1)

    def __str__(self):
        return str(self.review_author)

#whenever new user is created a token should br generated..
#this can be achieved using SIGNALS..

@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_auth_token(sender, instance=None, created=False, **kwargs):
    if created:
        Token.objects.create(user=instance)
