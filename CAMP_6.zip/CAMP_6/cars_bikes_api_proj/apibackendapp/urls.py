
from django.urls import path

from . import views
from .views import post_list,review_list,category_list,post_details_view,search

urlpatterns = [
    path('posts', post_list),
    path('reviews', review_list),
    path('categorys', category_list),
    path('post/<int:passed_id>', post_details_view, name='post_details'),
    path('post/<str:passed_post>', search),
    path('api/user/signup/', views.SignupAPIView.as_view(), name="user-signup"),
    path('api/user/login/', views.LoginAPIView.as_view(), name="user-login"),
]
