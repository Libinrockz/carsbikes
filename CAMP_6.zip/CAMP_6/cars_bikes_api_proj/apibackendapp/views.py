from django.contrib.auth import authenticate
from django.core.exceptions import ObjectDoesNotExist
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.authtoken.models import Token
from rest_framework.decorators import permission_classes, api_view
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView

from .models import Post, Reviews, Category
from .serializers import PostSerializer, ReviewsSerializer, CategorySerializer, SignupSerializer, LoginSerializer

# Create your views here.

from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
#implement logic for signup class based views
class SignupAPIView(APIView):
    print("sdfghjhgfd")
    def post(self, request):
        print("im here")
        serializer = SignupSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            res = {'status': status.HTTP_201_CREATED}
            return Response(res, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginAPIView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            username= serializer.validated_data["username"]
            password= serializer.validated_data["password"]
            user = authenticate(request, username=username, password=password)

            if user is not None:
                token = Token.objects.get(user=user)
                response = {
                    "status": status.HTTP_200_OK,
                    "message": "success",
                    "data": {
                         "Token": token.key
                    }
                }
                return Response(response, status=status.HTTP_200_OK)
            else:
                response = {
                    "status": status.HTTP_401_UNAUTHORIZED,
                    "message": "Wrong Credentials",
                }
                return Response(response, status=status.HTTP_401_UNAUTHORIZED)

        response = {
            "status": status.HTTP_400_BAD_REQUEST,
            "message": "bad request",

        }
        return Response(response, status=status.HTTP_400_BAD_REQUEST)

@csrf_exempt
# @api_view(['GET', 'POST'])
# @permission_classes((IsAuthenticated, ))
def post_list(request):
    if request.method == 'GET':
        posts_list = Post.objects.all()
        posts_list_serializer = PostSerializer(posts_list, many= True)
        return JsonResponse(posts_list_serializer.data, safe=False, status=200)

    elif request.method == 'POST':
        post_title = request.POST.get('post_title')
        post_description = request.POST.get('post_description')
        post_shortname = request.POST.get('post_shortname')
        post_author = request.POST.get('post_author')
        category = request.POST.get('category')
        post_image = request.FILES.get('post_image')
        request_data = {
            'post_title': post_title,
            'post_description': post_description,
            'post_shortname': post_shortname,
            'post_author': post_author,
            'category': category,
            'post_image': post_image
        }

        #request_data = JSONParser().parse(request)
        post_add_serializer = PostSerializer(data = request_data)
        if post_add_serializer.is_valid():
            post_add_serializer.save()
            return JsonResponse(post_add_serializer.data, status=201)
        return JsonResponse(post_add_serializer.errors, status=400)

@csrf_exempt
# @api_view(['GET', 'POST'])
# @permission_classes((IsAuthenticated, ))
def review_list(request):
    if request.method == 'GET':
        reviews_list = Reviews.objects.all()
        reviews_list_serializer = ReviewsSerializer(reviews_list, many= True)
        return JsonResponse(reviews_list_serializer.data, safe=False)

    elif request.method == 'POST':
        request_data = JSONParser().parse(request)
        review_add_serializer = ReviewsSerializer(data = request_data)
        if review_add_serializer.is_valid():
            review_add_serializer.save()
            return JsonResponse(review_add_serializer.data, status=201)
        return JsonResponse(review_add_serializer.errors, status=400)

@csrf_exempt
# @api_view(['GET', 'POST'])
# @permission_classes((IsAuthenticated, ))
def category_list(request):
    if request.method == 'GET':
        categorys_list = Category.objects.all()
        categorys_list_serializer = CategorySerializer(categorys_list, many= True)
        return JsonResponse(categorys_list_serializer.data, safe=False)

    elif request.method == 'POST':
        request_data = JSONParser().parse(request)
        category_add_serializer = CategorySerializer(data = request_data)
        if category_add_serializer.is_valid():
            category_add_serializer.save()
            return JsonResponse(category_add_serializer.data, status=201)
        return JsonResponse(category_add_serializer.errors, status=400)


@csrf_exempt
# @api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes((IsAuthenticated, ))
def post_details_view(request, passed_id):
    # to get the single object based on the id
    try:
        post_details = Post.objects.get(id=passed_id)
    except Post.DoesNotExist:
        return HttpResponse(status=404)
    if request.method == 'GET':
       post_detail_serializer = PostSerializer(post_details)
       return JsonResponse(post_detail_serializer.data, safe=False, status=200)


    elif request.method == 'PUT':
        # for saving the data we need to parse to JSON format
        request_data = JSONParser().parse(request)
        post_update_serializer = PostSerializer(post_details, data=request_data)
        if post_update_serializer.is_valid():
            post_update_serializer.save()
            return JsonResponse(post_update_serializer.data, safe=False, status=201)

        return JsonResponse(post_update_serializer.errors, safe=False, status=400)

    elif request.method == 'DELETE':
        post_details.delete()
        return HttpResponse(status=204)


@csrf_exempt
# @api_view(['GET'])
#
# @permission_classes((IsAuthenticated, ))
def search(request, passed_post):
    try:
        post_details = Post.objects.filter(post_shortname__icontains=passed_post) | Post.objects.filter(post_title__icontains=passed_post)
        if not post_details.exists():
            raise Exception("Not Found")
    except Exception as e:
        return JsonResponse({'error': 'No matching posts found'}, status=404)

    if request.method == "GET":
        post_detail_serializer = PostSerializer(post_details,many=True)
        return JsonResponse(post_detail_serializer.data,safe=False,status=200)


