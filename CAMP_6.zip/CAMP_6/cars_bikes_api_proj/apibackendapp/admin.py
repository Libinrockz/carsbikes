from django.contrib import admin
from rest_framework.authtoken.models import Token

from .models import Category,Post,Reviews
# Register your models here.

admin.site.register(Token)
admin.site.register(Category)
admin.site.register(Post)
admin.site.register(Reviews)